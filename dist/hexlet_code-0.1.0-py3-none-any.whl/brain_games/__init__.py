"""Game 'Brain games'."""
